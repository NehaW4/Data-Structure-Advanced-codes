/*Read the marks obtained by students of second year in an online examination of
particular subject. Find out maximum and minimum marks obtained in that subject. Use
heap data structure. Analyze the algorithm.*/


#include<iostream>
using namespace std;
# define max 20
class student
{
    int marks[max];
    public:
    student()
    {
        for(int i=0;i<max;i++)
        marks[i]=0;
    }
    void insert_heap(int total);
    void display_heap(int total);
    void showmax(int total);
    void showmin();
};
void student::insert_heap(int total)
{
    for(int i=1;i<=total;i++)
    {
        cout<<"Enter Marks:";
        cin>>marks[i];
        int j=i;
        int parent=j/2;
        while(marks[j]<=marks[parent] && j!=0)
        {
            int temp=marks[j];
            marks[j]=marks[parent];
            marks[parent]=temp;
            j=parent;
            parent=j/2;
        }
    }
}
void student::display_heap(int total)
{
    int i=1,space=6;
    cout<<endl;
    while(i<=total)
    {
        if(i==1|| i==2|| i==4 || i==8 ||i==16)
        {
            cout<<endl;
            for(int j=0;j<space;j++)
            cout<<" ";
            space-=2;
        }
        cout<<" "<<marks[i];
        i++;
    }
}
void student::showmax(int total)
{
    int max1=marks[1];
    for(int i=2;i<=total;i++)
        {
            if(max1<marks[i])
            max1=marks[i];
        }
    cout<<"MAX Marks"<<max1;
}
void student::showmin()
{
    cout<<"MIN Marks:"<<marks[1];
}
int main()
{
    int ch,c,total;
    student s1;
    do{
        cout<<endl<<"*****MENU*****";
        cout<<endl<<"1.Read Marks of the Student";
        cout<<endl<<"2.Display MIN Heap";
        cout<<endl<<"3.Find MAX Marks";
        cout<<endl<<"4.Find MIN Marks";
        cout<<endl<<"--->Enter choice-->";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"How many Students:";
                cin>>total;
                s1.insert_heap(total);
                break;
        
        case 2:
            s1.display_heap(total);
            break;
        case 3:
            s1.showmax(total);
            break;
        case 4:
            s1.showmin();
            break;
        }
        cout<<"\n"<<"DO U WANT TO CONTINUE?(1 for continue)";
        cin>>c;
    }while(c==1);
    return 0;
}

