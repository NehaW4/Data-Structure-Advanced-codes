'''
Consider telephone book database of N clients. Make use of a hash table
implementation to quickly look up client‘s telephone number. Make use of two collision
handling techniques and compare them using number of comparisons required to find a
set of telephone numbers

'''

class hashing:
    def __init__(self):
        self.size= int(input("Enter the size of the table:"))
        self.count= 0
        self.hashTable= [None for i in range(self.size)]
        
    def hashFunction(self, ele):
            return(ele%self.size)
            
    def isFull(self):
            if(self.count== self.size):
                return True
            else:
                return False
                
    def inserting(self, ele):
            if(self.isFull()):
                print("\nHASH TABLE is full...")
            else:
                if(self.hashTable[self.hashFunction(ele)]== None):
                    self.hashTable[self.hashFunction(ele)]= ele
                    self.count += 1 
                
                    print(self.hashTable)
                else: 
                    self.collision(ele)
              
                
        
    def collision(self,ele):
        print("\n1-Linear Probing\n2-Quadratic Probing\n")
        ch = int(input("Enter your choice: "))
        match(ch):
            case 1:
                self.linear(ele)
            case 2:
                self.quadratic(ele)
                
                
                
    def linear(self , ele):
        hk= self.hashFunction(ele)
        flag=0
        for i in range(hk, self.size):
            if(self.hashTable[i] == None):
                self.hashTable[i] = ele
                self.count += 1
                flag = 1
                print("\nElement placed successfully!!\n")
                print(self.hashTable)
                break
        if (flag == 0):
            print("\nThis element cannot be placed in hash table!!")
            
            
    def quadratic(self , ele):
        y = self.hashFunction(ele)
        flag = 0
        for i in range(self.size):
            h1 = (y + (i**2))%self.size
            if(self.hashTable[h1] == None):
                self.hashTable[h1] = ele
                flag = 1
                self.count += 1 
                print("\nElement placed successfully!!\n")
                print(self.hashTable)
                break
        if(flag == 0):
            print("\nThis element cannot be placed!")

obj = hashing()
n = int(input("Enter how many numbers you want to add: "))
for i in range(n):
    ele1 = int(input("\nEnter element to insert: "))
    obj.inserting(ele1)
                
                    
            



