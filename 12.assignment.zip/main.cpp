/*
Department maintains a student information. The file contains roll number, name,
division and address. Allow user to add, delete information of student. Display
information of particular employee. If record of student does not exist an appropriate
message is displayed. If it is, then the system displays the student details. Use sequential
file to main the data. */

#include<iostream>
#include<fstream>
using namespace std;
class student
{
    int roll_no;
    char Name[30];
    char Div[5];
    char Address[50];
    
    public:
    void accept();
    void display();
    int rollno()
    {
        return roll_no;
    }
    
};
void student::accept()
{
    cout<<"\nEnter Roll no:";
    cin>>roll_no;
    cout<<"\nEnter Name:";
    cin.ignore();
    cin.getline(Name,30);
    cout<<"\n Enter Division:";
    cin>>Div;
    cout<<"\nEnter Address:";
    cin.ignore();
    cin.getline(Address,50);
    cout<<"\n";
}
void student::display()
{
    cout<<"\n"<<roll_no<<"\t\t"<<Name<<"\t\t"<<Div<<"\t\t"<<Address;
}
void create()
{
    student s;
    int n,i;
    ofstream out("Student.txt");
    cout<<"\nHow Many records do you want to enter:";
    cin>>n;
    for(i=0;i<n;i++)
    {
       s.accept();
       out.write((char*)&s,sizeof(s));
    }
    out.close();
}
void search()
{
    int n,flag=0;
    cout<<"\nEnter Roll Number To be Searched:";
    cin>>n;
    ifstream infile("Student.txt");
    student s;
    while(infile.read((char*)&s,sizeof(s)))
    {
        if(s.rollno()==n)
        {
            cout<<"\n**Record FOUND**\n";
            cout<<"\nRoll number        Name        Division        Address";
            s.display();
            flag=1;
            break;
        }
        
    }
    if(flag==0)
    {
        cout<<"\nRecord NOT FOUND!!!!!";
    }
    infile.close();
}
void display()
{
    student s;
    ifstream infile("Student.txt");
    while(infile.read((char*)&s,sizeof(s)))
    {
        s.display();
    }
    infile.close();
}
void add_record()
{
    student s;
    ofstream outfile("Student.txt",ios::app);
    s.accept();
    outfile.write((char*)&s,sizeof(s));
    outfile.close();
    cout<<"Record SUCCESSFULLY Added";
}
void delete_record()
{
    int n,flag=0;
    cout<<"\nEnter the Roll no whose Record To be deleted:";
    cin>>n;
    ifstream infile("Student.txt");
    ofstream temp("temp.txt");
    //file(temporary file)
    student s;
    while(infile.read((char*)&s,sizeof(s)))
    {
        if(s.rollno()!=n)
        {
            temp.write((char*)&s,sizeof(s));
        }
        else
        {
            flag=1;
            cout<<"\nRecord SUCCESSFULLY Deleted";
        }
    }
    if(flag==0)
    {
        cout<<"Record NOT FOUND!!";
    }
    infile.close();
    temp.close();
    remove("Student.txt");
    rename("temp.txt","Student.txt");
    
}
int main()
{
    int choice;
    ofstream out("Student.txt");
    out.close();
    do{
        cout<<"\n";
        cout<<"\nMenu\n1]Create\n2]Display\n3]Add Record\n4]Search record\n5]Delete Record\n6]Exit";
        cout<<"--->Enter Choice--->";
        cin>>choice;
        switch(choice)
        {
            case 1:
                cout<<"\n";
                create();
                break;
            case 2:
                cout<<"\n";
                cout<<"\n Roll No.      Name        Division        Address";
                display();
                break;
            case 3:
                cout<<"\n";
                add_record();
                break;
            case 4:
                cout<<"\n";
                search();
                break;
            case 5:
                cout<<"\n";
                delete_record();
                break;
            case 6:
                cout<<"Exited";
                break;
        }
    }while(choice!=6);
    return 0;
}



